# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:14
# @Author : liujin
# @Site :
# @File : index.py
# @Software: PyCharm
from Controller import app
@app.get("/Version",summary='接口服务验证')
async def read_root():
    return {"code":0,"msg": "欢迎访问喷雾器发货单结算系统接口 ！"}