# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:28
# @Author : liujin
# @Desc :
# @File : creation_token.py
# @Software: PyCharm

import jwt
import time
def get_token(userid):
    '''
    创建token
    :param userid:
    :return:
    '''
    secret = b'xinhai520'
    expire_time = int(time.time() + 7100)  #  1.9 小时后超时

    encoded = jwt.encode({'data': userid, 'exp': expire_time}, secret, algorithm='HS256')
    encoded_str = str(encoded)
    return encoded_str

# print(get_token(1314520))