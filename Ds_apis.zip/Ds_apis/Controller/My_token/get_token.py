# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:28
# @Author : liujin
# @remarks :
# @File : get_token.py
# @Software: PyCharm

import jwt
def get_token(encoded_str):
    '''
    解析验证token
    :param encoded_str:
    :return:
    '''
    secret = b'xinhai520'
    try:
        info = jwt.decode(encoded_str, secret, algorithms=["HS256"])
        return True,info
    except jwt.PyJWTError:
        return False,'身份验证异常'

# dome
# print(get_token("eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyaWQiOjEyMzQ1LCJleHAiOjE2MzE1MjcyMzR9.G3A36HVWzVjIK-7VLYvwCIOhQumHgiEvAMNp0GoQHr0"))