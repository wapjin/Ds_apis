# -*- coding: utf-8 -*-
# @Time : 2021/9/22 0022 上午 8:30
# @Author : liujin
# @remarks : 发票单搜索接口
# @File : invoice_list.py
# @Software: PyCharm 


def  get_list_cdefine10(cdefine10):
    try:
        from Model.Document_retrieval.ERP_packing_table import session,erp_sales_t,erp_sales_w,engine
        from sqlalchemy import func,and_

        # if cdefine10:
        #
        #     item_list1 = session.query(erp_sales_w).filter(erp_sales_w.cdefine33 == cdefine10).all()
        #     cinvname_name_list=[]
        #     for item1 in item_list1:
        #             if item1.cinvname not in cinvname_name_list:
        #                 cinvname_name_list.append(item1.cinvname)
        #     cinvname_name_list_one=[]
        #     for cinvname_name in cinvname_name_list:
        #         dd={}
        #         shu=0
        #         cwhname=""
        #
        #         cinvname_names = session.query(erp_sales_w).filter(and_(erp_sales_w.cdefine33 == cdefine10,erp_sales_w.cinvname==cinvname_name)).all()
        #         for cinvname_names_list in cinvname_names:
        #             shu = cinvname_names_list.iquantity+shu
        #             cwhname = cinvname_names_list.cwhname
        #             cinvm_unit = cinvname_names_list.cinvm_unit
        #         dd["iquantity"]=int(shu)
        #         dd["cinvname"]=cinvname_name
        #         dd["cwhname"]=cwhname
        #         dd["cdefine10"]=cdefine10
        #         dd["cinvm_unit"]=cinvm_unit
        #
        #         cinvname_name_list_one.append(dd)
        #     engine.dispose()
        #     return cinvname_name_list_one
        if cdefine10:
            item_list = session.query(erp_sales_t).filter(erp_sales_t.cdefine10 == cdefine10).all()

            cdefine9 = 0
            cdlcode_list = []
            for item in item_list:
                # print(item.cdlcode)
                # if item.cdlcode not in cdlcode_list:
                #     cdlcode_list.append(item.cdlcode)
                cdefine9 = item.cdefine9
            print(cdlcode_list)
            cinvname_name_list=[]
            # for cdlcode_d in cdlcode_list:
                # item_list1 = session.query(erp_sales_w).filter(erp_sales_w.cbsysbarcode == cdlcode_d).all()
            item_list1 = session.query(func.sum(erp_sales_w.iquantity),erp_sales_w.cinvname,erp_sales_w.cinvstd,erp_sales_w.cwhname,erp_sales_w.cinvm_unit).filter(
erp_sales_w.cdefine33==cdefine10
).group_by(erp_sales_w.cinvname,erp_sales_w.cinvstd,erp_sales_w.cwhname,erp_sales_w.cinvm_unit).all()

            data_arr=[]
            for item1 in item_list1:
                data_json = {}
                # item1.cwhname
                data_json["iquantity"]=int(item1[0])
                data_json["cinvname"]=item1[1]
                data_json["cinvstd"]=item1[2]
                data_json["cdefine9"] = cdefine9
                data_json["cdefine10"] = cdefine10
                data_json["cwhname"] = item1[3]
                data_json["cinvm_unit"] = item1[4]
                print(item1)
                data_arr.append(data_json)

                # print(item1.cwhname)
                #
                # print(item1.cdefine33)
                # print(item1.iquantity)
                # if item1.cinvname not in cinvname_name_list:
                #     cinvname_name_list.append(item1.cinvname)
            # print(cinvname_name_list)
            # cinvname_name_list_one = []
            # for cinvname_name in cinvname_name_list:
            #     dd={}
            #     shu=0
            #     cwhname=""
            #     for cdlcode_d in cdlcode_list:
            #         cinvname_names = session.query(erp_sales_w).filter(and_(erp_sales_w.cbsysbarcode == cdlcode_d,erp_sales_w.cinvname==cinvname_name)).all()
            #         for cinvname_names_list in cinvname_names:
            #             shu = cinvname_names_list.iquantity+shu
            #             cwhname = cinvname_names_list.cwhname
            #             cinvm_unit = cinvname_names_list.cinvm_unit
            #     dd["iquantity"]=int(shu)
            #     dd["cinvname"]=cinvname_name
            #     dd["cwhname"]=cwhname
            #     dd["cdefine10"]=cdefine10
            #     dd["cinvm_unit"]=cinvm_unit
            #     dd["cdefine9"]=cdefine9
            #
            #     cinvname_name_list_one.append(dd)
            engine.dispose()
            return data_arr
    except Exception as ex:
        print(ex)
        engine.dispose()
        return None
# print(get_list_cdefine10("AFA210-35IR"))
# print(get_list_cdefine10("AFA210-37FLA-XC"))
# exit()
from Controller import *
@app.get("/backend/invoice/list",summary='发票单搜索接口')
async def trans_lists(*,token: str = Header(None),cdefine10:str):
    tk = get_token(token)
    if tk[0] or debug:
        # tk[1].get("userid")
        # 记录人员查询操作
        try:
            list = get_list_cdefine10(cdefine10)
            data = {
                "code":0,
                "msg":"查询成功",
                "data":{
                    "list":list,
                    "count":len(list)
                }

            }
        except Exception as ex:
            print(ex)
            data = {
                "code": 1,
                "msg": "查询异常",

            }
        return data
    else:
        return {"code":1,"msg":tk[1]}