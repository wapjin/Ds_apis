from fastapi import FastAPI, Header, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from Controller.My_token.get_token import get_token
app = FastAPI(title='喷雾器发货单结算系统接口')
# 调用配置文件
from Config.config import *
# 跨域访问设置
app.add_middleware(
    CORSMiddleware,
    allow_origins=ip_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# debug=False

# 调用模块文件
from Controller.index import *
from Controller.Login.login import *
from Controller.Login.sm_login import *
# from Controller.Document_retrieval.ERP_transfer.list import *
# from Controller.Document_retrieval.ERP_transfer.details import *
from Controller.Document_retrieval.ERP_packing.list import *
from Controller.Document_retrieval.ERP_packing.details import *
from Controller.Settlement_voucher.invoice_list import *
from Controller.data_dictionary.contact_unit_add import *
from Controller.data_dictionary.contact_unit_list import *
from Controller.data_dictionary.product_cost_add import *
from Controller.data_dictionary.product_cost_list import *
