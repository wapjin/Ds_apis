# 登录
# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:27
# @Author : liujin
# @remarks :
# @File : login.py
# @Software: PyCharm

def Login(user,passwd):
    '''
    用户登录验证
    :param user:
    :param passwd:
    :return:
    '''
    # from Model.login.login_table import session
    # from Model.login.login_table import Login
    # item_list = session.query(Login).filter(Login.gonghao==user,Login.passwd==passwd).all()
    # print(item_list)
    # for item in item_list:
    #     print(item.gonghao, item.passwd)
    import requests,json
    user_data = json.loads(requests.post("http://172.16.38.29:8080/user/login",json={"job_number":str(user),"password":str(passwd)}).text)
    # print(user_data)

    if user_data["code"]=="0":
        user_datas = json.loads(requests.get("http://172.16.38.29:8080/user/getUser",headers={"token": user_data["t"]}).text)
        # print(user_datas)
        if user_datas["code"]=="0":

            from Controller.My_token.creation_token import get_token
            return {"code":0,"msg":"身份验证通过","token":str(get_token(user)),"data":user_datas["t"]}

    else:
        return {"code": 1, "msg": "身份验证失败"}
# Login("820012","root")
# exit()
from Controller import app
from pydantic import BaseModel
class login_data(BaseModel):
    '''
    接收接口参数
    用户名和密码
    '''
    user: str
    passwd: str
@app.post("/user/login",summary='账号密码登录接口')
async def read_root(*, data: login_data):
    try:
        # pass
        return Login(data.user, data.passwd)
    except:
        from Controller.My_token.creation_token import get_token
        return {"code": 0, "msg": "身份验证通过", "token": str(get_token(data.user)), "data": data.user}