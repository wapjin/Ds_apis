# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:28
# @Author : liujin
# @remarks :
# @File : sm_login.py
# @Software: PyCharm

from Controller import app
from pydantic import BaseModel

# 登录验证
def Login(code):
    '''
    登录验证
    :param code:
    :return:
    '''
    # 此处验证code，获取信息userid
    if len(code):

            import requests, json

            user_datas = json.loads(
                requests.get("http://172.16.38.29:8080/user/getUser", headers={"token": code}).text)
            # print(user_datas)
            if user_datas["code"] == "0":
                from Controller.My_token.CreationToken import get_token
                return {"code": 0, "msg": "身份验证通过", "token": str(get_token(code)), "data": user_datas["t"]}

            else:
                return {"code": 1, "msg": "身份验证失败"}

    else:
        return {"code": 1, "msg": "身份验证失败", "token": ""}

class login_data(BaseModel):
    code: str
@app.post("/sm_login",summary='钉钉扫码登录接口')
async def sm_logins(*, data: login_data):
    return Login(data.code)