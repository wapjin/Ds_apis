# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:26
# @Author : liujin
# @remarks :
# @File : details.py
# @Software: PyCharm

def  get_lists(cdlcode,page,limit):
    from Model.Document_retrieval.ERP_packing_table import session,erp_sales_w
    from sqlalchemy import func
    from sqlalchemy import and_

    item_list = session.query(erp_sales_w).filter(and_(erp_sales_w.cbsysbarcode == cdlcode)).order_by(erp_sales_w.autoid.desc()).limit(limit).offset(
                    (page-1)*limit).all()
    count = session.query(func.count(erp_sales_w.autoid)).filter(and_(erp_sales_w.cbsysbarcode == cdlcode)).scalar()
    list = []
    for item in item_list:
            print(item)
            list.append(item)
    return list,count


from Controller import *
from Controller.My_token.get_token import get_token
@app.get("/backend/ERP_packing/details",summary='装箱单详细接口')
async def trans_lists(*,token: str = Header(None),cdlcode:str,page:int=1,limit:int=30):
    tk = get_token(token)
    if tk[0] or 1:
        # tk[1].get("userid")
        # 记录人员查询操作
        list = get_lists(cdlcode,page,limit)
        data = {
            "code":0,
            "msg":"查询成功",
            "data":{
                "list":list[0],
                "count":list[1]
            }

        }
        return data
    else:
        return {"code":1,"msg":tk[1]}