# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:27
# @Author : liujin
# @remarks : 装箱单列表接口文件
# @File : list.py
# @Software: PyCharm
from Controller import *
from Controller.My_token.get_token import get_token

# 发货日期 ddate datetime8筛选发货单号 cdlcode varchar 60筛选内部发货单号cdefine2 varchar 40筛选
# 发票号码cdefine10 varchar 120 筛选发货序号 cdefine12 varchar 240筛选
def  get_list(ddate1,ddate2,cdlcode,cdefine2,cdefine10,cdefine12,page,limit):
    from Model.Document_retrieval.ERP_packing_table import session
    from Model.Document_retrieval.ERP_packing_table import erp_sales_t
    from Model.Document_retrieval.ERP_packing_table import engine
    from sqlalchemy import func
    from sqlalchemy import and_
    s_list=[]
    if cdlcode:
        s_list.append(erp_sales_t.cdlcode==cdlcode)
    if cdefine2:
        s_list.append(erp_sales_t.cdefine2 == cdefine2)
    if cdefine10:
        s_list.append(erp_sales_t.cdefine10 == cdefine10)
    if cdefine12:
        s_list.append(erp_sales_t.cdefine12 == cdefine12)
    if ddate1 and ddate2:
        s_list.append(and_(ddate1<=erp_sales_t.ddate,erp_sales_t.ddate<=ddate2))

    if len(s_list) == 1:
        item_list = session.query(erp_sales_t).filter(and_(s_list[0])).order_by(erp_sales_t.createdate.desc()).limit(limit).offset(
                    (page-1)*limit).all()
        count = session.query(func.count(erp_sales_t.cdefine2)).filter(and_(s_list[0])).scalar()
    if len(s_list) == 2:
        item_list = session.query(erp_sales_t).filter(and_(s_list[0],s_list[1],)).order_by(erp_sales_t.createdate.desc()).limit(
            limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_sales_t.cdefine2)).filter(and_(s_list[0],s_list[1])).scalar()
    if len(s_list) == 3:
        item_list = session.query(erp_sales_t).filter(and_(s_list[0],s_list[1],s_list[2],)).order_by(erp_sales_t.createdate.desc()).limit(
            limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_sales_t.cdefine2)).filter(and_(s_list[0],s_list[1],s_list[2])).scalar()
    if len(s_list) == 4:
        item_list = session.query(erp_sales_t).filter(and_(s_list[0],s_list[1],s_list[2],s_list[3],)).order_by(erp_sales_t.createdate.desc()).limit(
            limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_sales_t.cdefine2)).filter(and_(s_list[0],s_list[1],s_list[2],s_list[3])).scalar()
    if len(s_list) == 5:
        item_list = session.query(erp_sales_t).filter(and_(s_list[0], s_list[1], s_list[2], s_list[3],s_list[4] )).order_by(
            erp_sales_t.createdate.desc()).limit(
            limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_sales_t.cdefine2)).filter(
            and_(s_list[0], s_list[1], s_list[2], s_list[3], s_list[4])).scalar()
    if len(s_list)==0:
        item_list = session.query(erp_sales_t).order_by(
            erp_sales_t.createdate.desc()).limit(
            limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_sales_t.cdefine2)).scalar()
    list = []
    for item in item_list:
        json_data={}
        json_data["cbustype"]=item.cbustype
        json_data["cstname"]=item.cstname
        json_data["ddate"]=str(item.ddate).replace("T"," ")
        json_data["cdlcode"]=item.cdlcode
        json_data["cdefine2"]=item.cdefine2
        json_data["ccusabbname"]=item.ccusabbname
        json_data["cdepname"]=item.cdepname
        json_data["cscname"]=item.cscname
        json_data["cdefine10"]=item.cdefine10
        json_data["cdefine12"]=item.cdefine12
        json_data["dverifysystime"]=str(item.dverifysystime).replace("T"," ")
        json_data["cmemo"]=item.cmemo
            # print(item)
        list.append(json_data)
    # 关闭数据库连接
    engine.dispose()
    return list,count

# p = get_list(ddate1,ddate2,cdlcode,cdefine2,cdefine10,cdefine12,1,10)
# print(p)
# print(len(p[0]))
# exit()

@app.get("/backend/ERP_packing/list",summary='装箱单列表接口')
async def trans_lists(*,token: str = Header(None),ddate1:str=None,ddate2:str=None,cdlcode:str=None,cdefine2:str=None,cdefine10:str=None,cdefine12:str=None,page:int=1,limit:int=30):
    tk = get_token(token)
    if tk[0] or 1:
        # tk[1].get("userid")
        # 记录人员查询操作
        list = get_list(ddate1,ddate2,cdlcode,cdefine2,cdefine10,cdefine12,page,limit)
        print(len(list[0]))
        data = {
            "code":0,
            "msg":"查询成功",
            "data":{
                "list":list[0],
                "count":list[1]
            }

        }
        return data
    else:
        return {"code":1,"msg":tk[1]}