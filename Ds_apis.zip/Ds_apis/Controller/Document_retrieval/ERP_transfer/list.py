
def  get_list(ctvcode,dnmaketime,cmaker,page,limit):
    from Model.Document_retrieval.ERP_transfer_table import session
    from Model.Document_retrieval.ERP_transfer_table import erp_trans
    from sqlalchemy import func
    from sqlalchemy import and_
    if ctvcode and dnmaketime and cmaker:
        item_list = session.query(erp_trans).filter(and_(erp_trans.ctvcode == ctvcode,erp_trans.dnmaketime.like("%"+dnmaketime+"%"),erp_trans.cmaker.like("%"+cmaker+"%"))).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
                    (page-1)*limit).all()

        count = session.query(func.count(erp_trans.ctvcode)).filter(and_(erp_trans.ctvcode == ctvcode,erp_trans.dnmaketime.like("%"+dnmaketime+"%"),erp_trans.cmaker.like("%"+cmaker+"%"))).scalar()

    elif ctvcode and dnmaketime:
        item_list = session.query(erp_trans).filter(
            and_(erp_trans.ctvcode == ctvcode, erp_trans.dnmaketime.like("%" + dnmaketime + "%"))).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
            (page - 1) * limit).all()

        count = session.query(func.count(erp_trans.ctvcode)).filter(
            and_(erp_trans.ctvcode == ctvcode, erp_trans.dnmaketime.like("%" + dnmaketime + "%"))).scalar()
    elif dnmaketime and cmaker:
        item_list = session.query(erp_trans).filter(
            and_(erp_trans.dnmaketime.like("%" + dnmaketime + "%"),
                 erp_trans.cmaker.like("%" + cmaker + "%"))).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
            (page - 1) * limit).all()

        count = session.query(func.count(erp_trans.ctvcode)).filter(
            and_( erp_trans.dnmaketime.like("%" + dnmaketime + "%"),
                 erp_trans.cmaker.like("%" + cmaker + "%"))).scalar()
    elif ctvcode and cmaker:
        item_list = session.query(erp_trans).filter(
            and_(erp_trans.ctvcode == ctvcode,
                 erp_trans.cmaker.like("%" + cmaker + "%"))).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_trans.ctvcode)).filter(
            and_(erp_trans.ctvcode == ctvcode,
                 erp_trans.cmaker.like("%" + cmaker + "%"))).scalar()
    elif ctvcode:
        item_list = session.query(erp_trans).filter(
            and_(erp_trans.ctvcode == ctvcode)).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(erp_trans.ctvcode)).filter(
            and_(erp_trans.ctvcode == ctvcode)).scalar()
    elif dnmaketime:
        item_list = session.query(erp_trans).filter(
            and_(erp_trans.dnmaketime.like("%" + dnmaketime + "%"))).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
            (page - 1) * limit).all()

        count = session.query(func.count(erp_trans.ctvcode)).filter(
            and_(erp_trans.dnmaketime.like("%" + dnmaketime + "%"))).scalar()
    elif cmaker:
        item_list = session.query(erp_trans).filter(
            and_(erp_trans.cmaker.like("%" + cmaker + "%"))).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
            (page - 1) * limit).all()

        count = session.query(func.count(erp_trans.ctvcode)).filter(and_(erp_trans.cmaker.like("%" + cmaker + "%"))).scalar()
    else:
        item_list = session.query(erp_trans).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
                    (page-1)*limit).all()
        count = session.query(func.count(erp_trans.ctvcode)).scalar()

    list = []
    for item in item_list:
            print(item)
            list.append(item)
    return list,count
from Controller import *
from Controller.My_token.get_token import get_token
@app.get("/backend/ERP_transfer/list",summary='调拨单列表接口')
async def trans_lists(*,token: str = Header(None),ctvcode:str=None,dnmaketime:str=None,cmaker:str=None,page:int=1,limit:int=30):
    tk = get_token(token)
    if tk[0] or debug:
        # tk[1].get("userid")
        # 记录人员查询操作
        list = get_list(ctvcode,dnmaketime,cmaker,page,limit)
        data = {
            "code":0,
            "msg":"查询成功",
            "data":{
                "list":list[0],
                "count":list[1]
            }

        }
        return data
    else:
        return {"code":1,"msg":tk[1]}