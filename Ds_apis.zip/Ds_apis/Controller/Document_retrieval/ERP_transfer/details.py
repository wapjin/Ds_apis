
def  get_list(ctvcode,page,limit):
    from Model.Document_retrieval.ERP_transfer_table import session
    from Model.Document_retrieval.ERP_transfer_table import erp_trans
    from sqlalchemy import func
    from sqlalchemy import and_

    item_list = session.query(erp_trans).filter(and_(erp_trans.ctvcode == ctvcode)).order_by(erp_trans.dnmaketime.desc()).limit(limit).offset(
                    (page-1)*limit).all()
    count = session.query(func.count(erp_trans.ctvcode)).filter(and_(erp_trans.ctvcode == ctvcode)).scalar()
    list = []
    for item in item_list:
            print(item)
            list.append(item)
    return list,count


from Controller import *
from Controller.My_token.get_token import get_token
@app.get("/backend/ERP_transfer/details",summary='调拨单详细接口')
async def trans_lists(*,token: str = Header(None),ctvcode:str,page:int=1,limit:int=30):
    tk = get_token(token)
    if tk[0] or debug:
        # tk[1].get("userid")
        # 记录人员查询操作
        list = get_list(ctvcode,page,limit)
        data = {
            "code":0,
            "msg":"查询成功",
            "data":{
                "list":list[0],
                "count":list[1]
            }

        }
        return data
    else:
        return {"code":1,"msg":tk[1]}