# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:22
# @Author : liujin
# @remarks :新增收货单位
# @File : contact_unit_add.py
# @Software: PyCharm
def contact_unit_adds(cumemo_data,cucode_data,cuname_data):
    try:
        from Model.data_dictionary.contact_unit_table import session, engine, tb_contact_unit
        from Config.now_time import nowtime
        user2 = tb_contact_unit(cumemo=cumemo_data,cucode=cucode_data,cuname=cuname_data,createdate=nowtime())
        session.add(user2)
        session.commit()
        session.close()
        engine.dispose()
        return True
    except Exception as ex:
        print(ex)
        session.close()
        engine.dispose()
        return False


from Controller import *
from pydantic import BaseModel
from Controller.My_token.get_token import get_token
class contact_unit_data(BaseModel):
    '''
    接收参数
    '''
    cumemo:str
    cucode:str
    cuname: str

@app.post("/backend/contact_unit_add",summary='新增收货单位接口')
async def contact_unit_add(*,token: str = Header(None), data: contact_unit_data):
    tk = get_token(token)
    if tk[0] or debug:
        if contact_unit_adds(data.cumemo, data.cucode, data.cuname):
            return {"code":0,"msg":"添加收货单位成功"}
        else:
            return {"code": 1, "msg": "添加收货单位失败"}


