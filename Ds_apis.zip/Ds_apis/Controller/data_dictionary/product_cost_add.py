# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:25
# @Author : liujin
# @remarks : 新增产品单价
# @File : product_cost_add.py
# @Software: PyCharm
def product_cost_adds(pcost,pmemo):
    try:
        from Model.data_dictionary.product_cost_table import session, engine,tb_product_cost
        from Config.now_time import nowtime
        # 金额pcost decimal 17备注pmemovarchar120
        user2 = tb_product_cost(pcost=pcost,pmemo=pmemo,createdate=nowtime())
        session.add(user2)
        session.commit()
        session.close()
        engine.dispose()
        return True
    except Exception as ex:
        print(ex)
        session.close()
        engine.dispose()
        return False

# product_cost_adds("0.1","原材料")
# exit()
from Controller import *
from pydantic import BaseModel
from Controller.My_token.get_token import get_token
from decimal import *
class product_cost_data(BaseModel):
    '''
    接收参数
    '''
    pcost: Decimal
    pmemo:str


@app.post("/backend/product_cost_add",summary='新增产品单价')
async def product_cost_add(*,token: str = Header(None), data: product_cost_data):
    tk = get_token(token)
    if tk[0] or debug:
        print(data)
        if product_cost_adds(data.pcost, data.pmemo):
            return {"code":0,"msg":"添加产品单价成功"}
        else:
            return {"code": 1, "msg": "添加产品单价失败"}
