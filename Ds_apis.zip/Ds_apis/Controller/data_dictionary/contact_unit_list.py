# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:24
# @Author : liujin
# @remarks :收货单位列表
# @File : contact_unit_list.py
# @Software: PyCharm
def get_list_tb_contact_unit(cucode,cuname,limit,page):
    from Model.data_dictionary.contact_unit_table import session, engine, tb_contact_unit
    from sqlalchemy import func
    if cucode:

        item_list = session.query(tb_contact_unit).filter(tb_contact_unit.cucode == cucode).order_by(
            tb_contact_unit.createdate.desc()).limit(limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(tb_contact_unit.autoid)).filter(tb_contact_unit.cucode == cucode).scalar()

    elif cuname:

        item_list = session.query(tb_contact_unit).filter(tb_contact_unit.cuname.like("%"+cuname+"%")).order_by(tb_contact_unit.createdate.desc()).limit(limit).offset(
            (page - 1) * limit).all()
        count = session.query(func.count(tb_contact_unit.autoid)).filter(tb_contact_unit.cuname.like("%"+cuname+"%")).scalar()

    else:
        item_list = session.query(tb_contact_unit).order_by(tb_contact_unit.createdate.desc()).limit(limit).offset(
                        (page-1)*limit).all()
        count = session.query(func.count(tb_contact_unit.autoid)).scalar()

    list = []
    for item in item_list:
            print(item)
            list.append(item)
    engine.dispose()
    return list,count

from Controller import *
@app.get("/backend/contact_unit_list",summary='发票单搜索接口')
async def contact_unit_list(*,token: str = Header(None),cucode:str=None,cuname:str=None,limit:int=30, page:int=1):
    tk = get_token(token)
    if tk[0] or debug:
        list = get_list_tb_contact_unit(cucode,cuname,limit, page)
        data = {
            "code": 0,
            "msg": "查询成功",
            "data": {
                "list": list[0],
                "count": list[1]
            }

        }
        return data
    else:
        return {"code": 1, "msg": tk[1]}
