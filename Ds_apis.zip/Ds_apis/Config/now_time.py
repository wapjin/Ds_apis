# -*- coding: utf-8 -*-
# @Time : 2021/9/23 0023 下午 1:36
# @Author : liujin
# @Site : 获取当前时间
# @File : now_time.py
# @Software: PyCharm 
import time
def nowtime(strftime="%Y-%m-%d %H:%M:%S"):
    return str(time.strftime(strftime, time.localtime()))