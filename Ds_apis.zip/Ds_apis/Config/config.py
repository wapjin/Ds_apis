# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:22
# @Author : liujin
# @Site :
# @File : config.py
# @Software: PyCharm
# ip白名单
ip_list=["*"]
# 数据库信息
mysql_config={
    "port":3306,
    "host":"172.16.1.23",
    "user":"db_caiwubu_01",
    "passwd":"Bx4554AyF0Qy",
    "db":"db_caiwubu_01"
}
# 调试模式配置
debug=True
