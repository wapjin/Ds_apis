# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:36
# @Author : liujin
# @remarks :
# @File : Run.py
# @Software: PyCharm

from Controller import *
# 启动入口
if __name__ == '__main__':
    import uvicorn
    import sys
    # Run.py 8081
    # if len(sys.argv)>1:
    #     uvicorn.run(app, host="0.0.0.0", port=int(sys.argv[1]))
    # else:
    #     print("请输入端口号")
    uvicorn.run(app="Controller:app", host="0.0.0.0", port=8081, reload=True)