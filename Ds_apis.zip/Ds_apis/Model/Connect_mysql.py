# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:36
# @Author : liujin
# @remarks :
# @File : Connect_mysql.py
# @Software: PyCharm

# 连接数据库

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine, Column, Integer,Float,Boolean,DECIMAL,DateTime,Time,String,Text,NVARCHAR,VARCHAR,Sequence
from sqlalchemy.orm import sessionmaker
from Config.config import *

DB_URI = f'mysql+pymysql://{mysql_config["user"]}:{mysql_config["passwd"]}@{mysql_config["host"]}:{mysql_config["port"]}/{mysql_config["db"]}'
try:
    engine = create_engine(DB_URI)
    Base = declarative_base(engine)  # SQLORM基类
    session = sessionmaker(engine)()  # 构建session对象
except Exception as ex:
    print(ex)
    engine.dispose()