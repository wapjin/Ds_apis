# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:33
# @Author : liujin
# @remarks :
# @File : product_cost_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class tb_product_cost(Base):
    '''
    创建tb_product_cost表模型
    产品单价表
    '''
    __tablename__ = 'tb_product_cost'  # 表名
    # 自增序号 pautoid int 10
    autoid = Column(Integer, primary_key=True, autoincrement=True)
    # 主键金额 pcost decimal 17
    pcost = Column(DECIMAL(17))
    # 备注 pmemo nvarchar 80
    pmemo = Column(VARCHAR(80))
    # 创建日期 createdate datetime 8
    createdate = Column(DateTime(8))

Base.metadata.create_all()  # 将模型映射到数据库中