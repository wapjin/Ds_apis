# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:32
# @Author : liujin
# @remarks :
# @File : contact_unit_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class tb_contact_unit(Base):
    '''
    创建tb_contact_unit表模型
    产品单价表
    '''
    __tablename__ = 'tb_contact_unit'  # 表名
    # 自增序号 pautoid int 10
    autoid = Column(Integer, primary_key=True,autoincrement=True)
    # 国备注cumemo varchar 120
    cumemo = Column(DECIMAL(120))
    # 备注 pmemo nvarchar 80
    # 单位编号cucode varchar40同产销国
    cucode = Column(VARCHAR(40))
    #   主键单位名称cuname varchar 80
    cuname = Column(VARCHAR(80))
    # 创建日期 createdate datetime 8
    createdate = Column(DateTime(8))

Base.metadata.create_all()  # 将模型映射到数据库中