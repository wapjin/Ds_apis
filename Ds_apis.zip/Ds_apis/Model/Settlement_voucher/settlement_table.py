# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:34
# @Author : liujin
# @remarks :
# @File : settlement_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class tb_settlement(Base):
    '''
    创建tb_settlement表模型
    财务出库单主表
    '''
    __tablename__ = 'tb_settlement'  # 表名
    # id = Column(Integer, primary_key=True, autoincrement=True)
    # 自增序号 autoid int 10
    autoid = Column(Integer, primary_key=True)
    # 主键购货单位 scname nvarchar 80
    scname = Column(VARCHAR(80))
    # 合同号 sccode nvarchar 120
    sccode = Column(VARCHAR(120))
    # 同发票单号制单日期 smaketime datetime 8
    smaketime = Column(DateTime(8))
    # 制单人 smaker nvarchar 40
    smaker = Column(VARCHAR(40))
    # 单位 sunit nvarchar 40
    sunit = Column(VARCHAR(40))
    # 总金额 stprice decimal 17
    stprice = Column(DECIMAL(17))
    # 大写金额 captprice nvarchar 80
    captprice = Column(VARCHAR(80))
    createdate = Column(DateTime(8))
class tb_settlement_data(Base):
    '''
    创建tb_settlement_data表模型
    财务出库单子表
    '''
    __tablename__ = 'tb_settlement_data'  # 表名
    # id = Column(Integer, primary_key=True, autoincrement=True)
    # 自增序号 autoid int 10
    # autoid = Column(Integer(10), primary_key=True, autoincrement=True)
    # 出库单序号 sautoid int 10
    autoid = Column(Integer, primary_key=True)
    # 品名 dpname nvarchar 120
    dpname = Column(VARCHAR(120))
    # 生产分厂 dfactory nvarchar 80
    dfactory = Column(VARCHAR(80))
    # 单位dunit nvarchar 40
    dunit = Column(VARCHAR(40))
    # 报关数量 dquantity decimal 17
    dquantity = Column(DECIMAL(17))
    # 报关单价 dcost decimal 17
    dcost = Column(DECIMAL(17))
    # 来源：数据字典报关金额 dtprice decimal 17
    dtprice = Column(DECIMAL(17))
    # 备注 dmemo nvarchar 80
    dmemo = Column(VARCHAR(80))
    createdate = Column(DateTime(8))
Base.metadata.create_all()  # 将模型映射到数据库中