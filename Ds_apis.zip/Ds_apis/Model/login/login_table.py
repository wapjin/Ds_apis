# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:34
# @Author : liujin
# @remarks :
# @File : login_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class Login(Base):
    '''
    创建表模型
    '''
    __tablename__ = 'x_user'  # 表名
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50))
    gonghao = Column(String(50))
    passwd = Column(String(50))
# Session = sessionmaker(bind=engine)
Base.metadata.create_all()  # 将模型映射到数据库中