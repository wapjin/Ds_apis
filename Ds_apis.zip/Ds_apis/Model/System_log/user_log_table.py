# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:35
# @Author : liujin
# @remarks :
# @File : user_log_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class tb_user_log(Base):
    '''
    创建tb_user_log表模型
    用户日志表
    '''
    __tablename__ = 'tb_user_log'  # 表名

    # 自增序号 autoid int 10
    autoid = Column(Integer, primary_key=True)
    # 主键用户名 uname nvarchar 40
    uname = Column(VARCHAR(40))
    # 操作类型 utype varchar 40
    utype = Column(VARCHAR(40))
    # 登录时间 ldtime datetime 8
    ldtime = Column(DateTime(8))
    # 登录设备 lequip nvarchar 120
    lequip = Column(VARCHAR(120))
    # 创建日期createdate datetime 8
    createdate = Column(DateTime(8))

Base.metadata.create_all()  # 将模型映射到数据库中