# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:35
# @Author : liujin
# @remarks :
# @File : erpsync_log_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class tb_user_log(Base):
    '''
    创建tb_erpsync_log表模型
    同步日志表
    '''
    __tablename__ = 'tb_erpsync_log'  # 表名

    # 自增序号 autoid int 10 主键
    autoid = Column(Integer, primary_key=True)
    # 同步内容 sydetail nvarchar 120
    sydetail = Column(VARCHAR(120))
    # 同步状态 systatus nvarchar 40
    systatus = Column(VARCHAR(40))
    # 执行时间 sydelay nvarchar 40
    sydelay = Column(VARCHAR(40))
    # 毫秒备注 symemo nvarchar 120
    symemo = Column(VARCHAR(120))
    # 创建日期 createdate datetime 8
    createdate = Column(DateTime(8))
Base.metadata.create_all()  # 将模型映射到数据库中