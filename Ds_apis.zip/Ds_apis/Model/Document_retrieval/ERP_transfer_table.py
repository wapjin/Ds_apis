from Model.Connect_mysql import *
class erp_trans(Base):
    '''
    创建erp_trans表模型
    调拨单   丢弃
    '''
    __tablename__ = 'erp_trans'  # 表名
    # id = Column(Integer, primary_key=True, autoincrement=True)
    # 单据号
    ctvcode = Column(NVARCHAR(60),primary_key=True)
    # 制单日期 datetime
    dnmaketime = Column(DateTime(8))
    # 转出仓库cwhname nvarchar40
    cwhname = Column(NVARCHAR(40))
    # 转入仓库cwhname_1 nvarchar40
    cwhname_1 = Column(NVARCHAR(40))
    # 审核日期dverifydate datetime8
    dverifydate = Column(DateTime(8))
    # 制单人cmaker nvarchar40
    cmaker = Column(NVARCHAR(40))
    # 审核人cverifyperson nvarchar40
    cverifyperson = Column(NVARCHAR(40))
    # 备注ctvmemo nvarchar120
    ctvmemo = Column(NVARCHAR(120))
    # 存货编码cinvcode nvarchar40
    cinvcode = Column(NVARCHAR(40))
    # 存货名称cinvname nvarchar510
    cinvname = Column(NVARCHAR(510))
    # 规格型号cinvstd nvarchar510
    cinvstd = Column(NVARCHAR(510))
    # 主计量单位cinvm_unit nvarchar40
    cinvm_unit = Column(NVARCHAR(40))
    # 数量itvquantitydecimal17
    itvquantity = Column(DECIMAL(17))
    # 单价itvacost decimal17
    itvacost = Column(DECIMAL(17))
    # 金额itvaprice decimal 17
    itvaprice = Column(DECIMAL(17))
    # 批号ctvbatch nvarchar 120
    ctvbatch = Column(String(120))
    # 表体备注 cbmemo nvarchar 510
    cbmemo = Column(NVARCHAR(510))
    # 同步日期 createdate datetime 8
    createdate = Column(DateTime(8))

Base.metadata.create_all()  # 将模型映射到数据库中