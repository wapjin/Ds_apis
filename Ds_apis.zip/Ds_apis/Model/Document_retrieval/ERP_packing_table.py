# -*- coding: utf-8 -*-
# @Time : 2021/9/18 0018 上午 10:33
# @Author : liujin
# @remarks :
# @File : ERP_packing_table.py
# @Software: PyCharm

from Model.Connect_mysql import *
class erp_sales_t(Base):
    '''
    创建erp_sales_t表模型
    装箱单主表
    '''
    __tablename__ = 'erp_sales_t'  # 表名
    autoid = Column(Integer, primary_key=True, autoincrement=True)
    # 业务类型cbustype nvarchar 16
    cbustype = Column(VARCHAR(16))
    # 销售类型cstname nvarchar 40
    cstname = Column(VARCHAR(40))
    # 发货日期ddate varchar 10
    ddate = Column(VARCHAR(10))
    # 发货单号cdlcode nvarchar 60
    cdlcode = Column(VARCHAR(60))
    # 内部发货单号cdefine2 nvarchar 40
    cdefine2 = Column(VARCHAR(40))
    # 客户简称ccusabbname nvarchar 120
    ccusabbname = Column(VARCHAR(120))
    # 销售部门cdepname nvarchar 510
    cdepname = Column(VARCHAR(510))
    # 发运方式cscname nvarchar 40
    cscname = Column(VARCHAR(40))
    # 发票号码cdefine10 nvarchar 120
    cdefine10 = Column(VARCHAR(120))
    # 目的地cshipaddress nvarchar 400
    # cshipaddress = Column(VARCHAR(400))
    # 考虑是否使用
    # 发货序号cdefine12 nvarchar 240
    cdefine12 = Column(VARCHAR(240))
    # 集装箱号 考虑是否使用 封箱号 考虑是否使用
    # 产销国cdefine9 nvarchar 16
    cdefine9 = Column(VARCHAR(16))
    # 审核日期dverifysystime datetime 8
    dverifysystime = Column(DateTime(8))
    # 备注cmemo nvarchar 120
    cmemo = Column(VARCHAR(120))
    # 制单人cmaker nvarchar 40
    cmaker = Column(VARCHAR(40))
    # 审核人cverifier nvarchar 40
    cverifier = Column(VARCHAR(40))
    # 同步日期 createdate datetime 8
    createdate = Column(DateTime(8))
class erp_sales_w(Base):
    '''
    创建erp_sales_t表模型
    装箱单子表
    '''
    __tablename__ = 'erp_sales_w'  # 表名
    # id = Column(Integer, primary_key=True, autoincrement=True)
    # 自增序号autoid int 10
    autoid = Column(Integer, primary_key=True, autoincrement=True)
    # 单据行条码cbsysbarcode nvarchar 160
    cbsysbarcode = Column(VARCHAR(160))
    # 关联主表发货单号仓库名称cwhname nvarchar 40
    cwhname = Column(VARCHAR(40))
    # 存货编码cinvcode nvarchar 40
    cinvcode = Column(VARCHAR(40))
    # 保税品cinvdefine3 nvarchar 40
    cinvdefine3 = Column(VARCHAR(40))
    # 发票号码cdefine33varchar120关联主表
    cdefine33 = Column(VARCHAR(120))
    # 存货名称cinvname nvarchar 510
    cinvname = Column(VARCHAR(510))
    # 规格型号cinvstd nvarchar 510
    cinvstd = Column(VARCHAR(510))
    # 单位cinvm_unit nvarchar 40
    cinvm_unit = Column(VARCHAR(40))
    # 数量iquantity decimal 17
    iquantity = Column(DECIMAL(17))
    # 批号cbatch nvarchar 120
    cbatch = Column(VARCHAR(120))
    # 新海描述cinvdefine7 nvarchar 240
    cinvdefine7 = Column(VARCHAR(240))
    # 同步日期 createdate datetime 8
    createdate = Column(DateTime(8))
# Base.metadata.create_all()  # 将模型映射到数据库中